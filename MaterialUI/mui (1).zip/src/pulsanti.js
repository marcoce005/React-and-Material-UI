import * as React from "react";

import DeleteIcon from "@mui/icons-material/Delete"; //icone per i pulsanti
import AlarmIcon from "@mui/icons-material/Alarm";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";
import IconButton from "@mui/material/IconButton";

import Button from "@mui/material/Button"; // per i bottoni

import { styled } from "@mui/material/styles"; // per i pulsanti con le immagini belle
import Box from "@mui/material/Box";
import ButtonBase from "@mui/material/ButtonBase";
import Typography from "@mui/material/Typography";

import ButtonGroup from "@mui/material/ButtonGroup"; // per i gruppi di pulsanti

import PhotoCamera from "@mui/icons-material/PhotoCamera"; // per pulsanti che aprono file telecamera

const images = [
  // fonte da dove prende le immagini
  {
    url:
      "https://www.corriere.it/methode_image/2021/11/03/Economia/Foto%20Economia%20-%20Trattate/312.0.1563300590-kiuF-U33005968061729fB-656x492@Corriere-Web-Sezioni.jpg",
    title: "Breakfast",
    width: "40%"
  },
  {
    url:
      "https://www.deabyday.tv/.imaging/default/article/guides/cucina-e-ricette/speciali/hamburger/Come-fare-gli-hamburger-al-formaggio/imageOriginal.jpg",
    title: "Burgers",
    width: "30%"
  },
  {
    url:
      "https://media-assets.wired.it/photos/615ea99945b72a756bd2b380/1:1/w_1280%2Cc_limit/9ebcbc78-6ac9-4172-98f1-6bc95662e922.jpg",
    title: "Camera",
    width: "30%"
  }
];

// impostazioni per adattare le immagini
const ImageButton = styled(ButtonBase)(({ theme }) => ({
  position: "relative",
  height: 200,
  [theme.breakpoints.down("sm")]: {
    width: "100% !important", // Overrides inline-style
    height: 100
  },
  "&:hover, &.Mui-focusVisible": {
    zIndex: 1,
    "& .MuiImageBackdrop-root": {
      opacity: 0.15
    },
    "& .MuiImageMarked-root": {
      opacity: 0
    },
    "& .MuiTypography-root": {
      border: "4px solid currentColor"
    }
  }
}));

const ImageSrc = styled("span")({
  position: "absolute",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  backgroundSize: "cover",
  backgroundPosition: "center 40%"
});

const Image = styled("span")(({ theme }) => ({
  position: "absolute",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: theme.palette.common.white
}));

const ImageBackdrop = styled("span")(({ theme }) => ({
  position: "absolute",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  backgroundColor: theme.palette.common.black,
  opacity: 0.4,
  transition: theme.transitions.create("opacity")
}));

const ImageMarked = styled("span")(({ theme }) => ({
  height: 3,
  width: 18,
  backgroundColor: theme.palette.common.white,
  position: "absolute",
  bottom: -2,
  left: "calc(50% - 9px)",
  transition: theme.transitions.create("opacity")
}));

const Input = styled("input")({
  // constanti per l'uso dei pulsanti che aprono file
  display: "none"
});

export default function IconButtons() {
  return (
    <Box direction="row" spacing={1}>
      <Box>
        <IconButton aria-label="delete">
          {" "}
          {/*Pulsanti con le icone*/}
          <DeleteIcon />
        </IconButton>
        <IconButton aria-label="delete" disabled color="primary">
          <DeleteIcon />
        </IconButton>
        <IconButton color="secondary" aria-label="add an alarm">
          <AlarmIcon />
        </IconButton>
        <IconButton color="primary" aria-label="add to shopping cart">
          <AddShoppingCartIcon />
        </IconButton>
      </Box>

      <br />

      <Box>
        <Button variant="text">Text</Button> {/*Pulsanti di vario tipo*/}
        <Button variant="contained">Contained</Button>
        <Button variant="outlined">Outlined</Button>
      </Box>

      <br />

      <Box
        sx={{ display: "flex", flexWrap: "wrap", minWidth: 300, width: "100%" }}
      >
        {" "}
        {/*Pulsanti con le immagini*/}
        {images.map((image) => (
          <ImageButton
            focusRipple
            key={image.title}
            style={{
              width: image.width
            }}
          >
            <ImageSrc style={{ backgroundImage: `url(${image.url})` }} />
            <ImageBackdrop className="MuiImageBackdrop-root" />
            <Image>
              <Typography
                component="span"
                variant="subtitle1"
                color="inherit"
                sx={{
                  position: "relative",
                  p: 4,
                  pt: 2,
                  pb: (theme) => `calc(${theme.spacing(1)} + 6px)`
                }}
              >
                {image.title}
                <ImageMarked className="MuiImageMarked-root" />
              </Typography>
            </Image>
          </ImageButton>
        ))}
      </Box>

      <br />

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          "& > *": {
            m: 1
          }
        }}
      >
        <ButtonGroup variant="outlined" aria-label="outlined button group">
          {" "}
          {/*Gruppi di pulsanti*/}
          <Button>One</Button>
          <Button>Two</Button>
          <Button>Three</Button>
        </ButtonGroup>
        <ButtonGroup variant="text" aria-label="text button group">
          <Button>One</Button>
          <Button>Two</Button>
          <Button>Three</Button>
        </ButtonGroup>
      </Box>

      <Box direction="row" alignItems="center" spacing={2}>
        {" "}
        {/*Pulsanti che agiscono (aprino file)*/}
        <label htmlFor="contained-button-file">
          <Input
            accept="image/*"
            id="contained-button-file"
            multiple
            type="file"
          />
          <Button variant="contained" component="span">
            Upload
          </Button>
        </label>
        <label htmlFor="icon-button-file">
          <Input accept="image/*" id="icon-button-file" type="file" />
          <IconButton
            color="primary"
            aria-label="upload picture"
            component="span"
          >
            <PhotoCamera />
          </IconButton>
        </label>
      </Box>
    </Box>
  );
}
