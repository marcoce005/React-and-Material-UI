import * as React from "react";
import ReactDOM from "react-dom/client";
import { StyledEngineProvider } from "@mui/material/styles";

import SceltaMultipla from "./sceltamultipla";
import Pulsanti from "./pulsanti";
import Check from "./checkbox";
import Pulsante_azione from "./pulsante_azione_mobile"
import Selezione from "./selezione"
import Valutazione from "./valutazione"
import Scorrimento from "./slider"
import Switch from "./switch"
import CampoTesto from "./campo_testo"
import Trasferimento from "./l_trasferimento"
import Word from "./menu_word"

ReactDOM.createRoot(document.querySelector("#root")).render(
  <React.StrictMode>
    <StyledEngineProvider injectFirst>

      <h1 align="center">Sceltamultipla Guidata</h1>
      <SceltaMultipla />

      <br />
      <hr />

      <h1 align="center">Pulsanti</h1>
      <Pulsanti />

      <br />
      <hr />

      <h1 align="center">Checkbox</h1>
      <Check />

      <br />
      <hr />

      <h1 align="center">Pulsante con azione mobile</h1>
      <Pulsante_azione />
      
      <br />
      <hr />

      <h1 align="center">Pulsanti di selezione</h1>
      <Selezione />
      
      <br />
      <hr />

      <h1 align="center">Valutazione</h1>
      <Valutazione />

      <br />
      <hr />

      <h1 align="center">Dispositivo di Scorrimento</h1>
      <Scorrimento />
      
      <br />
      <hr />

      <h1 align="center">Interruttore</h1>
      <Switch />
      
      <br />
      <hr />

      <h1 align="center">Campo di Testo</h1>
      <CampoTesto />
      
      <br />
      <hr />

      <h1 align="center">Lista di trasferimento</h1>
      <Trasferimento />
      
      <br />
      <hr />

      <h1 align="center">Menu di word</h1>
      <Word />
    </StyledEngineProvider>
  </React.StrictMode>
);
