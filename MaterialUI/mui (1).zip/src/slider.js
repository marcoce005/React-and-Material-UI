import * as React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";

import Grid from "@mui/material/Grid"; // per gli slider
import Typography from "@mui/material/Typography";
import Slider from "@mui/material/Slider";
import MuiInput from "@mui/material/Input";
import VolumeUp from "@mui/icons-material/VolumeUp";

const Input = styled(MuiInput)`
  width: 60px;
`;

export default function InputSlider() {
  const [value, setValue] = React.useState(12); // valore di partenza

  const handleSliderChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleInputChange = (event) => {
    setValue(event.target.value === "" ? "" : Number(event.target.value));
  };

  const handleBlur = () => {
    if (value < 0) {
      setValue(0);
    } else if (value > 100) {
      setValue(100);
    }
  };

  function preventHorizontalKeyboardNavigation(event) {
    // per lo slider orrizzontale
    if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      event.preventDefault();
    }
  }

  return (
    <Box sx={{ width: 250 }}>
      <Typography id="input-slider" gutterBottom>
        Volume
      </Typography>
      <Grid container spacing={2} alignItems="center">
        <Grid item>
          <VolumeUp />
        </Grid>
        <Grid item xs>
          <Slider
            value={typeof value === "number" ? value : 0}
            onChange={handleSliderChange}
            aria-labelledby="input-slider"
            color="secondary"
          />
        </Grid>
        <Grid item>
          <Input
            value={value}
            size="small"
            onChange={handleInputChange}
            onBlur={handleBlur}
            inputProps={{
              step: 10,
              min: 0,
              max: 100,
              type: "number",
              "aria-labelledby": "input-slider"
            }}
          />
        </Grid>
      </Grid>

      <br />
      <div align="center">
        <Box sx={{ height: 300 }}>
          <Slider
            sx={{
              '& input[type="range"]': {
                WebkitAppearance: "slider-vertical"
              }
            }}
            orientation="vertical"
            defaultValue={12}
            aria-label="Temperature"
            valueLabelDisplay="auto"
            color="secondary"
            onKeyDown={preventHorizontalKeyboardNavigation}
          />
        </Box>
      </div>
    </Box>
  );
}
