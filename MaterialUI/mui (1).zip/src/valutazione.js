import * as React from "react";
import Box from "@mui/material/Box";

import Rating from "@mui/material/Rating"; // per la prima valutazione
import Typography from "@mui/material/Typography";

import StarIcon from "@mui/icons-material/Star"; // per la valutazione con giudizio a fianco

import PropTypes from "prop-types"; // per la valutazione con le faccine
import { styled } from "@mui/material/styles";
import SentimentVeryDissatisfiedIcon from "@mui/icons-material/SentimentVeryDissatisfied";
import SentimentDissatisfiedIcon from "@mui/icons-material/SentimentDissatisfied";
import SentimentSatisfiedIcon from "@mui/icons-material/SentimentSatisfied";
import SentimentSatisfiedAltIcon from "@mui/icons-material/SentimentSatisfiedAltOutlined";
import SentimentVerySatisfiedIcon from "@mui/icons-material/SentimentVerySatisfied";

export default function BasicRating() {
  const [value, setValue] = React.useState(1); //valore pre-impostato per il primo
  const [hover, setHover] = React.useState(-1);

  const labels = {
    // valori che assume il giudizio
    0.5: "Useless",
    1: "Useless+",
    1.5: "Poor",
    2: "Poor+",
    2.5: "Ok",
    3: "Ok+",
    3.5: "Good",
    4: "Good+",
    4.5: "Excellent",
    5: "Excellent+"
  };

  function getLabelText(value) {
    return `${value} Star${value !== 1 ? "s" : ""}, ${labels[value]}`;
  }

  const StyledRating = styled(Rating)(({ theme }) => ({
    "& .MuiRating-iconEmpty .MuiSvgIcon-root": {
      color: theme.palette.action.disabled
    }
  }));

  const customIcons = {
    1: {
      icon: <SentimentVeryDissatisfiedIcon color="error" />,
      label: "Very Dissatisfied"
    },
    2: {
      icon: <SentimentDissatisfiedIcon color="error" />,
      label: "Dissatisfied"
    },
    3: {
      icon: <SentimentSatisfiedIcon color="warning" />,
      label: "Neutral"
    },
    4: {
      icon: <SentimentSatisfiedAltIcon color="success" />,
      label: "Satisfied"
    },
    5: {
      icon: <SentimentVerySatisfiedIcon color="success" />,
      label: "Very Satisfied"
    }
  };

  function IconContainer(props) {
    const { value, ...other } = props;
    return <span {...other}>{customIcons[value].icon}</span>;
  }

  IconContainer.propTypes = {
    value: PropTypes.number.isRequired
  };

  return (
    <Box
      sx={{
        "& > legend": { mt: 1 } //distanza tra una riga e l'altra
      }}
    >
      <Typography component="legend">
        Parte già da un valore impostato
      </Typography>{" "}
      {/*Il valore che riceve lo memorizza in quello visivo e in quello disabilitato*/}
      <Rating
        name="simple-controlled"
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
      />
      <Typography component="legend">Solo visivo</Typography>
      <Rating name="read-only" value={value} readOnly />
      <Typography component="legend">Disabilitato</Typography>
      <Rating name="disabled" value={value} disabled />
      <Typography component="legend">
        Nessuna valutazione iniziale
      </Typography>{" "}
      {/*Non tiene memorizzato il valore che gli viene assegnato*/}
      <Rating name="no-value" value={null} />
      <br />
      <Box // valutazione con risulato a fianco
        sx={{
          width: 200,
          display: "flex",
          alignItems: "center"
        }}
      >
        <Rating
          name="hover-feedback"
          value={value}
          precision={0.5}
          getLabelText={getLabelText}
          onChange={(event, newValue) => {
            setValue(newValue);
          }}
          onChangeActive={(event, newHover) => {
            setHover(newHover);
          }}
          emptyIcon={<StarIcon style={{ opacity: 0.55 }} fontSize="inherit" />}
        />
        {value !== null && (
          <Box sx={{ ml: 2 }}>{labels[hover !== -1 ? hover : value]}</Box>
        )}
      </Box>
      <br />
      <StyledRating // valutazione con le faccine
        name="highlight-selected-only"
        defaultValue={3}
        IconContainerComponent={IconContainer}
        getLabelText={(value) => customIcons[value].label}
        highlightSelectedOnly
      />
    </Box>
  );
}
